#This is the command to use to start the script

java -jar extractor-1.0.jar [path] [text]

#For windows provide path like: c:\\temp\\file.log

exemple :
java -jar extractor-1.0.jar C:\\Users\\User\\AppData\\Local\\PokerStars\\PokerStars.log.0 "UpdateMyCard"
